from cdr_processor import CDRAnalyzer
from detection_engine import SuspicionDetector
from location_analyzer import LocationTriangulator

class CDRApp:
    def __init__(self, file_path):
        self.analyzer = CDRAnalyzer(file_path)
        self.detector = SuspicionDetector(self.analyzer.df)
        self.locator = LocationTriangulator()

    def generate_full_report(self):
        report = {}

        report['max_messaged_number'] = self.analyzer.get_max_messaged_number()
        report['most_active_number'] = self.analyzer.get_most_active_number()
        report['frequently_called'] = self.analyzer.get_frequently_called()
        report['statistics'] = self.analyzer.get_call_statistics()

        report['suspicious_alerts'] = self.detector.detect_suspicious_patterns()
        report['crime_patterns'] = self.detector.crime_pattern_matcher()

        report['location_clusters'] = self.locator.get_location_clusters(self.analyzer.df)

        return report