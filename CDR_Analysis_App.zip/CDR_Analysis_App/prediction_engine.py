def predict_behavior(df):
    if df['hour'].between(0, 5).sum() > 10:
        return "Abnormal night activity detected"

    if df['duration'].mean() < 30:
        return "Short burst communication pattern"

    return "Normal behavior"