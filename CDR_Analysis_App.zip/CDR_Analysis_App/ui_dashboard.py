import streamlit as st
import pandas as pd
import plotly.express as px
import numpy as np

# ---------------- PAGE CONFIG ----------------
st.set_page_config(page_title="CDR Intelligence System", layout="wide")
st.title("📊 CDR Intelligence Dashboard")

uploaded_file = st.file_uploader("Upload CSV", type=["csv"])

if uploaded_file:

    # -------- LOAD --------
    df = pd.read_csv(uploaded_file)
    df.columns = df.columns.str.strip().str.lower()

    if "type" in df.columns:
        df.rename(columns={"type": "call_type"}, inplace=True)

    # -------- CLEAN --------
    if "duration" in df.columns:
        df["duration"] = df["duration"].astype(str).str.replace("sec", "", regex=False)
        df["duration"] = pd.to_numeric(df["duration"], errors="coerce").fillna(0)
    else:
        df["duration"] = 0

    if "date" in df.columns and "time" in df.columns:
        df["datetime"] = pd.to_datetime(df["date"] + " " + df["time"], errors="coerce")
        df["hour"] = df["datetime"].dt.hour
        df["date_only"] = df["datetime"].dt.date
        df["day"] = df["datetime"].dt.day_name()

    # -------- SIDEBAR NAV --------
    page = st.sidebar.radio(
        "Navigate",
        ["Overview", "Analysis", "Timelines", "Insights", "Location", "Report"]
    )

    # -------- FILTERS --------
    st.sidebar.subheader("Filters")

    if "datetime" in df.columns:
        min_date = df["datetime"].min().date()
        max_date = df["datetime"].max().date()
        date_range = st.sidebar.date_input("Date Range", [min_date, max_date])

        if len(date_range) == 2:
            df = df[(df["datetime"].dt.date >= date_range[0]) &
                    (df["datetime"].dt.date <= date_range[1])]

    if "duration" in df.columns:
        min_d, max_d = st.sidebar.slider(
            "Duration Range",
            0,
            int(df["duration"].max()) if len(df) else 100,
            (0, int(df["duration"].max()) if len(df) else 100)
        )
        df = df[(df["duration"] >= min_d) & (df["duration"] <= max_d)]

    if "call_type" in df.columns:
        selected_types = st.sidebar.multiselect(
            "Call Type",
            df["call_type"].unique(),
            default=df["call_type"].unique()
        )
        df = df[df["call_type"].isin(selected_types)]

    # -------- OVERVIEW --------
    if page == "Overview":

        total_calls = len(df)
        total_duration = df["duration"].sum()
        avg_duration = df["duration"].mean()

        most_active = df["number"].value_counts().idxmax()

        col1, col2, col3 = st.columns(3)
        col1.metric("Total Calls", total_calls)
        col2.metric("Total Duration", int(total_duration))
        col3.metric("Avg Duration", round(avg_duration, 2))

        st.subheader("📞 Most Active Number")
        st.write(most_active)

        st.subheader("📊 Top Contacts")
        st.dataframe(df["number"].value_counts().head(10))

    # -------- ANALYSIS --------
    elif page == "Analysis":

        if "call_type" in df.columns:
            st.subheader("📊 Call Type Distribution")
            type_counts = df["call_type"].value_counts().reset_index()
            type_counts.columns = ["type", "count"]

            st.plotly_chart(px.pie(type_counts, names="type", values="count"))
            st.plotly_chart(px.bar(type_counts, x="type", y="count"))

        st.subheader("📊 Frequent Numbers")
        freq = df["number"].value_counts().head(10).reset_index()
        freq.columns = ["number", "count"]
        st.plotly_chart(px.bar(freq, x="number", y="count"))

        st.subheader("⏱ Duration Analysis")
        dur = df.groupby("number")["duration"].sum().reset_index().head(10)
        st.plotly_chart(px.bar(dur, x="number", y="duration"))

    # -------- TIMELINES --------
    elif page == "Timelines":

        if "datetime" not in df.columns:
            st.error("Datetime not available")
        else:
            st.subheader("⏰ Hourly Activity")
            st.bar_chart(df["hour"].value_counts().sort_index())

            st.subheader("📈 Daily Trend")
            daily = df.groupby("date_only").size().reset_index(name="calls")
            st.plotly_chart(px.line(daily, x="date_only", y="calls", markers=True))

            if "call_type" in df.columns:
                st.subheader("📊 Call Type Timeline")
                trend = df.groupby(["date_only", "call_type"]).size().reset_index(name="count")
                st.plotly_chart(px.line(trend, x="date_only", y="count", color="call_type"))

            st.subheader("⏱ Duration Over Time")
            dur = df.groupby("date_only")["duration"].mean().reset_index()
            st.plotly_chart(px.line(dur, x="date_only", y="duration"))

            st.subheader("🔥 Top Contacts Over Time")
            top = df["number"].value_counts().head(3).index
            filt = df[df["number"].isin(top)]
            trend2 = filt.groupby([filt["date_only"], "number"]).size().reset_index(name="count")
            st.plotly_chart(px.line(trend2, x="date_only", y="count", color="number"))

    # -------- INSIGHTS --------
    elif page == "Insights":

        st.subheader("🔍 Search Number")
        search_num = st.text_input("Enter Number")

        if search_num:
            st.dataframe(df[df["number"] == search_num])

        if "hour" in df.columns:
            peak = df["hour"].value_counts().idxmax()
            st.info(f"Most activity around {peak}:00 hrs")

        st.subheader("🚨 Alerts")

        alerts = []
        for num, group in df.groupby("number"):
            if len(group) > 50:
                alerts.append(f"{num} → High frequency")
            if group["duration"].sum() > 10000:
                alerts.append(f"{num} → Long duration")

        if alerts:
            for a in alerts:
                st.warning(a)
        else:
            st.success("No suspicious activity")

        st.subheader("🔥 Heatmap")
        if "day" in df.columns:
            heat = df.pivot_table(index="day", columns="hour", values="number", aggfunc="count")
            st.dataframe(heat)

        st.subheader("🔗 Network Insight")
        connections = df.groupby("number").size().sort_values(ascending=False).head(10)
        st.bar_chart(connections)

    # -------- LOCATION --------
    elif page == "Location":

        st.subheader("📍 Location (Simulated)")

        nums = df["number"].astype(str).unique()

        loc_df = pd.DataFrame({
            "lat": np.random.uniform(12.90, 13.10, len(nums)),
            "lon": np.random.uniform(77.50, 77.70, len(nums))
        })

        st.map(loc_df)

    # -------- REPORT --------
    elif page == "Report":

        st.subheader("📄 Report")

        total_calls = len(df)
        total_duration = int(df["duration"].sum())
        avg_duration = df["duration"].mean()

        most_active = df["number"].value_counts().idxmax()
        most_active_count = df["number"].value_counts().max()

        report = f"""
CDR ANALYSIS REPORT

Total Calls: {total_calls}
Total Duration: {total_duration}
Average Duration: {avg_duration:.2f}

Most Active Number:
{most_active} ({most_active_count} calls)

Top Contacts:
{df['number'].value_counts().head().to_string()}
"""

        if "call_type" in df.columns:
            report += f"\n\nCall Type Distribution:\n{df['call_type'].value_counts().to_string()}"

        st.text(report)

        st.download_button("Download Report", report, "cdr_report.txt")

else:
    st.info("Upload a CSV file to begin")