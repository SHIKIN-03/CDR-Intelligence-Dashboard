import random

class LocationTriangulator:
    def __init__(self):
        pass

    def get_location_clusters(self, df):
        clusters = []

        for num in df['number'].unique():
            clusters.append({
                "number": num,
                "lat": random.uniform(12.9, 13.1),
                "lon": random.uniform(77.5, 77.7)
            })

        return clusters