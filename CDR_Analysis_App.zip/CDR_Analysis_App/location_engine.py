import random

class LocationTriangulator:
    def get_location(self, number):
        # Fake telecom data
        mcc = "404"
        mnc = "45"
        cell_id = hash(number) % 10000

        # Fake coordinates
        lat = 12.9 + random.uniform(-0.05, 0.05)
        lon = 77.5 + random.uniform(-0.05, 0.05)

        return {
            "number": number,
            "mcc": mcc,
            "mnc": mnc,
            "cell_id": cell_id,
            "lat": lat,
            "lon": lon
        }