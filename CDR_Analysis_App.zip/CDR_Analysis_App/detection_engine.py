class SuspicionDetector:
    def __init__(self, df):
        self.df = df

    def detect_suspicious_patterns(self):
        alerts = []

        counts = self.df['number'].value_counts()

        for num, count in counts.items():
            if count > 10:
                alerts.append({
                    "number": num,
                    "reason": f"This number is suspicious because it made {count} calls",
                    "severity": "HIGH"
                })

        return alerts

    def crime_pattern_matcher(self):
        patterns = []

        high_duration = self.df[self.df['duration'] > 300]

        for _, row in high_duration.iterrows():
            patterns.append({
                "number": row['number'],
                "pattern": "Long duration call detected"
            })

        return patterns