import pandas as pd
import random
from datetime import datetime, timedelta

# Generate 1000 sample CDR records
data = []
start_date = datetime(2024, 1, 1)
numbers = [f"+91{random.randint(7000000000, 9999999999)}" for _ in range(20)]

for _ in range(1000):
    caller = random.choice(numbers)
    recipient = random.choice([n for n in numbers if n != caller])
    duration = random.randint(10, 3600)
    days_offset = random.randint(0, 30)
    hour = random.randint(0, 23)
    datetime_val = start_date + timedelta(days=days_offset, hours=hour)
    cell_id = random.choice([101, 102, 103, 104, 105])
    
    data.append({
        'caller': caller,
        'recipient': recipient,
        'duration': duration,
        'datetime': datetime_val,
        'cell_id': cell_id,
        'mcc': 404,
        'mnc': random.choice([1, 2]),
        'call_type': random.choice(['outgoing', 'incoming'])
    })

df = pd.DataFrame(data)
df.to_csv('sample_data/sample_cdr.csv', index=False)
print("Sample data generated with 1000 records")