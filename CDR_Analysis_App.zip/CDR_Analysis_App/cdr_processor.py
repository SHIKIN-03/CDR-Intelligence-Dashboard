import pandas as pd

class CDRAnalyzer:
    def __init__(self, file_path):
        self.df = pd.read_csv(file_path)

        # Clean columns
        self.df.columns = self.df.columns.str.strip().str.lower()

        # Rename if needed
        self.df.rename(columns={
            'number': 'number',
            'duration': 'duration'
        }, inplace=True)

        # Fix duration
        self.df['duration'] = self.df['duration'].astype(str)
        self.df['duration'] = self.df['duration'].str.replace('sec', '', regex=False)
        self.df['duration'] = self.df['duration'].str.strip()
        self.df['duration'] = pd.to_numeric(self.df['duration'], errors='coerce').fillna(0)

        # Fix number
        self.df['number'] = self.df['number'].astype(str)

    def get_max_messaged_number(self):
        return self.df['number'].value_counts().idxmax()

    def get_most_active_number(self):
        counts = self.df['number'].value_counts()
        return str(counts.idxmax()), int(counts.max())

    def get_frequently_called(self, top_n=5):
        return self.df['number'].value_counts().head(top_n).to_dict()

    def get_call_statistics(self):
        return {
            "total_calls": len(self.df),
            "total_duration": int(self.df['duration'].sum()),
            "avg_duration": float(self.df['duration'].mean())
        }